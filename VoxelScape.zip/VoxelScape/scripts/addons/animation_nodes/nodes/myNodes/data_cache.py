import bpy
from bpy.props import *
from collections import defaultdict
from ... sockets.info import toIdName
from ... base_types import AnimationNode

dataByIdentifier = defaultdict(dict)


class DataCacheNode(bpy.types.Node, AnimationNode):
    bl_idname = "an_DataCacheNode"
    bl_label = "Data Cache"

    #data = dict()

    def reset(self, context):
        pass

    enabled: BoolProperty(name = "Enabled", default = True, update = reset)

    def create(self):
        self.newInput("Generic", "Key", "key")
        self.newInput("Generic", "Value", "value")
        self.newInput("Boolean", "Flag", "flag")

        self.newOutput("Generic", "Value", "value")
        self.newOutput("Boolean", "Not Found", "notfound")

    def draw(self, layout):
        icon = "LAYER_ACTIVE" if self.enabled else "LAYER_USED"
        layout.prop(self, "enabled", text = "Enabled", icon = icon)

    '''
    def getExecutionCode(self, required):
        rtn_scripts = ["value, notfound = self.update(key, value)"]
        return rtn_scripts

    def update(self, key, value):
        if self.enabled: 
            if key in dataByIdentifier[self.identifier]:
                return dataByIdentifier[self.identifier][key], False
        else:
            dataByIdentifier[self.identifier][key] = value
    #'''

    #'''
    def getExecutionCode(self, required):
        rtn_scripts = [ "self.updateFlag(flag)",
                        "notfound = self.getnotFound(key)", 
                        "self.setValue(key, value)", 
                        "value = self.getValue(key)"]
        return rtn_scripts

    def updateFlag(self, flag):
        self.enabled = flag
        return flag

    def setFlag(self, flag):
        dataByIdentifier[self.identifier].flag = flag
        self.enabled = flag

    def getFlag(self):
        return dataByIdentifier[self.identifier].flag

    def setValue(self, key, value):
        if self.enabled and key in dataByIdentifier[self.identifier]:
            pass
        else:
            dataByIdentifier[self.identifier][key] = value

    def getValue(self, key):
        return dataByIdentifier.get(self.identifier)[key]

    def getnotFound(self, key):
        return not self.enabled or key not in dataByIdentifier[self.identifier]

    @property
    def notfound(self):
        return self.getFound()

    @property
    def value(self):
        return self.getValue()

    @value.setter
    def value(self, key, value):
        self.setValue(key, value)

    @property
    def flag(self):
        self.getFlag()

    @flag.setter
    def flag(self, flag):
        self.setFlag(flag)
    #'''
